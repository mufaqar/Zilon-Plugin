<?php 


echo "asdasdf";